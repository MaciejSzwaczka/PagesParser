import java.util.Set;

/**
 *
 * @author Sebastian Puzio 2017
 */
public class Category {
    private int ID;
    private String name;
    public Category(int ID,String name)
    {
        this.ID=ID;
        this.name=name;
    }
}
