import java.util.Set;
/**
 *
 * @author Sebastian Puzio 2017
 */

public class Product {
    private int ID;
    private String name;
    private double price;
    private Set<String> img;
    private String description;
    private Set<String> sizes;
    private String season;
    private String colour;
    private int active=1;
    private int amount=200;
    private int inSale=1;

   /* private String */

    public Product(int ID,String name,double price,Set<String> img,String description,
                   Set<String> sizes,String season,String colour){
        this.ID=ID;
        this.name=name;
        this.price=price;
        this.img=img;
        this.description=description;
        this.sizes=sizes;
        this.season=season;
        this.colour=colour;

    }
    public int getID()
    {
        return ID;
    }
    public String getName()
    {
        return name;
    }
    public double getPrice()
    {
        return price;
    }
    public Set<String> getImg()
    {
        return img;
    }
    public Set<String> getSizes()
    {
        return sizes;
    }
    public String getSeason()
    {
        return season;
    }
    public String getDescription()
    {
        return description;
    }
    public String getColour()
    {
        return colour;
    }
    public int getActive()
    {
        return active;
    }
    public int getAmount()
    {
        return amount;
    }
    public int getInSale()
    {
        return inSale;
    }
}
