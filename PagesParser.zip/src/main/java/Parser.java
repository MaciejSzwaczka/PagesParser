/**
 * Created by maciejszwaczka on 02.11.2017.
 */
import jdk.nashorn.internal.runtime.regexp.joni.Regex;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.*;

import org.apache.poi.hssf.*;
import sun.nio.cs.StandardCharsets;

public class Parser {
    public int index;
    public Parser()
    {
        this.index=0;
    }
    public List<Product> parse(String url)
    {
        List<Product> products=new ArrayList<Product>();
        Document doc=null;
        for(int pageIndex=1;5>pageIndex;pageIndex++) {
            try {
                doc = Jsoup.connect(url+pageIndex+"/").userAgent("Mozilla").timeout(10000).get();
            } catch (IOException e) {
                e.printStackTrace();
            }
        /*product-box col-xs-12-6 col-xs-12 col-sm-4 col-md-3 col-lg-2*/
            Elements elems = doc.getElementsByClass("product-box");
            for (Element elem : elems) {
                System.out.println(index);
                String name = elem.getElementsByClass("name").text();
                String sizesStr = elem.getElementsByClass("sizes").text();
                String priceStr = elem.getElementsByClass("price").text();
                double price = Double.parseDouble(priceStr.split(" ")[0]);
                Set<String> sizes = new TreeSet<String>();

                Set<String> imgSrc = new TreeSet<String>();
                String partsSizes[] = sizesStr.split(": ");
                partsSizes = partsSizes[1].split(",");
                for (String part : partsSizes) {
                    sizes.add(part);
                }
                Elements imagesSources = elem.getElementsByClass("photo-box");
                String status = elem.getElementsByClass("badge").text();

                for (Element element : imagesSources) {
                    Elements srcs = element.getElementsByTag("img");
                    for (Element src : srcs) {
                        imgSrc.add(src.absUrl("src"));
                    }
                }
                Document detailInfo = null;
                try {
                    detailInfo = Jsoup.connect(elem.getElementsByTag("a").first().absUrl("href")).timeout(100000).userAgent("Mozilla").get();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Elements elements = detailInfo.getElementsByClass("col-xs-12-6");
                int ind = 0;
            /*for(Element el:elements)
            {
                if(ind==0||ind==1) {
                    System.out.println(el.text());
                }
                ind++;
            }*/
                String season = null, product = null, colour = null;
                for (Element element : elements) {
                    if (ind < 2) {
                    /*System.out.print(element.html());*/
                        Elements tagNames = element.getElementsByTag("h4");
                        Elements values = element.getElementsByTag("p");
                        int i = 0;
                        for (Element str : tagNames) {
                            if (str.text().equals("Sezon:")) {
                                season = values.get(i).text();
                            } else if (str.text().equals("Produkt:")) {
                                product = values.get(i).text();
                            } else if (str.text().equals("Kolor:")) {
                                colour = values.get(i).text();
                            }
                            i++;
                        }
                    }
                    ind++;
                }
                Product prod = new Product(index, name, price, imgSrc, product, sizes, season, colour);
                products.add(prod);
                index++;
            }
        }
        return products;
    }
    public void parseToCSV(List<Product> products,String category)
    {
        File file=new File(category+".csv");
        /*HSSFWorkbook workbook=new HSSFWorkbook();
        HSSFSheet sheet=workbook.createSheet("data");
        HSSFRow row=sheet.createRow(0);
        row.createCell(0).setCellValue("ID");
        row.createCell(1).setCellValue("Nazwa");
        row.createCell(2).setCellValue("Cena");
        row.createCell(3).setCellValue("Obrazy");
        row.createCell(4).setCellValue("Opis");
        row.createCell(5).setCellValue("Rozmiar");
        row.createCell(6).setCellValue("Sezon");
        row.createCell(7).setCellValue("Kolor");
        int rowNum=1;
        for(Product prod:products)
        {
            row=sheet.createRow(rowNum);
            String sizes="";
            String imgs="";
            for(String size:prod.getSizes())
            {
                if(!sizes.equals("")) {
                    sizes = sizes + "," + size;
                }
                else
                {
                    sizes=size;
                }
            }
            for(String img:prod.getImg())
            {
                if(!imgs.equals("")) {
                    imgs = imgs + "," + img;
                }
                else
                {
                    imgs=img;
                }
            }
            row.createCell(0).setCellValue(prod.getID());
            row.createCell(1).setCellValue(prod.getName());
            row.createCell(2).setCellValue(prod.getPrice());
            row.createCell(3).setCellValue(imgs);
            row.createCell(4).setCellValue(prod.getDescription());
            row.createCell(5).setCellValue(sizes);
            row.createCell(6).setCellValue(prod.getSeason());
            row.createCell(7).setCellValue(prod.getColour());
            rowNum++;
        }
        FileOutputStream fileOutputStream=null;
        OutputStreamWriter outputStreamWriter=null;
        try
        {
            file.createNewFile();
            System.setProperty("file.encoding","UTF-8");

            fileOutputStream = new FileOutputStream(file);
            workbook.write(fileOutputStream);
            fileOutputStream.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }*/
        FileOutputStream fileOutputStream=null;
        BufferedOutputStream bufferedOutputStream=null;
        try{
            fileOutputStream=new FileOutputStream(file);
            bufferedOutputStream=new BufferedOutputStream(fileOutputStream);
            bufferedOutputStream.write("ID; Nazwa; Cena; Obrazy; Opis; Cechy; Aktywność; Ilość; W sprzedaży \n".getBytes());
            int ind=0;
            for(Product product: products)
            {
                String sizes="";
                String imgs="";
                for(String size:product.getSizes())
                {
                    if(!sizes.equals("")) {
                        sizes = sizes + " " + size;
                    }
                    else
                    {
                        sizes=size;
                    }
                }
                for(String img:product.getImg())
                {
                    if(!imgs.equals("")) {
                        imgs = imgs + "," + img;
                    }
                    else
                    {
                        imgs=img;
                    }
                }
                String feature="Rozmiary: "+sizes;
                if(product.getColour()!=null) {
                    feature += ", Kolor: " + product.getColour();
                }
                if(product.getSeason()!=null) {
                    feature += ", Sezon: " + product.getSeason();
                }
                    bufferedOutputStream.write(String.valueOf(product.getID()).getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(product.getName().getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(String.valueOf(product.getPrice()).getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(imgs.getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    if(product.getDescription()!=null) {
                        bufferedOutputStream.write(product.getDescription().getBytes());
                    }
                    else {
                        bufferedOutputStream.write(" ".getBytes());
                    }
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(feature.getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(String.valueOf(product.getActive()).getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(String.valueOf(product.getAmount()).getBytes());
                    bufferedOutputStream.write(";".getBytes());
                    bufferedOutputStream.write(String.valueOf(product.getInSale()).getBytes());
                    bufferedOutputStream.write("\n".getBytes());
                }
                ind++;

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (NullPointerException x)
        {
            x.printStackTrace();
        }

    }
}
