import java.util.*;
/**
 * Created by maciejszwaczka on 02.11.2017.
 */
public class Main {
    public static void main(String[] args)
    {
        Parser parser=new Parser();
        List<Product> mensWear=parser.parse("https://www.citysport.com.pl/kategoria/odziez/bluzy-meskie/");
        mensWear.addAll(parser.parse("https://www.citysport.com.pl/kategoria/odziez/koszulki-meskie/"));
        mensWear.addAll(parser.parse("https://www.citysport.com.pl/kategoria/odziez/dresy-meskie/"));


        List<Product> childsWear=parser.parse("https://www.citysport.com.pl/kategoria/odziez/bluzy-dzieciece/");
        childsWear.addAll(parser.parse("https://www.citysport.com.pl/kategoria/odziez/dresy-dzieciece/"));
        childsWear.addAll(parser.parse("https://www.citysport.com.pl/kategoria/odziez/koszulki-dzieciece/"));

        List<Product> mensBoots=parser.parse("https://www.citysport.com.pl/kategoria/buty/buty-meskie/");
        System.out.println("C");
        List<Product> womensBoots= parser.parse("https://www.citysport.com.pl/kategoria/buty/buty-damskie/");
        System.out.println("D");
        List<Product> childsBoots=parser.parse("https://www.citysport.com.pl/kategoria/buty/buty-dzieciece/");
        System.out.println("E");
        List<Product> womensWear=parser.parse("https://www.citysport.com.pl/kategoria/odziez/bluzy-damskie/");
        womensWear.addAll(parser.parse("https://www.citysport.com.pl/kategoria/odziez/koszulki-damskie/"));
        parser.parseToCSV(mensBoots,"buty_meskie");
        parser.parseToCSV(mensWear,"odziez_meska");
        parser.parseToCSV(childsBoots,"buty_dzieciece");
        parser.parseToCSV(womensBoots, "buty_damskie");
        parser.parseToCSV(childsWear,"odziez_dziecieca");
        parser.parseToCSV(womensWear,"odziez_damska");
    }
}
